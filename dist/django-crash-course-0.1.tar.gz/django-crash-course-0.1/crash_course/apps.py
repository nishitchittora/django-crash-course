from django.apps import AppConfig


class CrashCourseConfig(AppConfig):
    name = 'crash_course'
