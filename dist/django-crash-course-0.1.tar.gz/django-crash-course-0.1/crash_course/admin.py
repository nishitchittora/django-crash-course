from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(CrashCourse)
admin.site.register(CourseChapter)
admin.site.register(ChapterSection)
